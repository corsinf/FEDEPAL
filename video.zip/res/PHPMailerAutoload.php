<?php
require_once("class.phpmailer.php");
require_once("class.smtp.php");
require_once("class.exception.php");

