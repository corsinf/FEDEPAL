<img src="images/install_admin.png" />
<h2><?php echo $title ?></h2>
<p><?php echo $body ?></p>
<a class="fore-color-1 text-underline" href="<?php echo $url ?>" target="_blank"><?php echo $cta ?></a>
