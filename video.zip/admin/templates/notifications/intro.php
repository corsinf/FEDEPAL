<h2><?php echo $title ?></h2>
<p><?php echo $body1 ?></p>
<p><?php echo $body2 ?></p>
<script>localStorage.setItem('dashboard-notifications-bar-dismissed', true);</script>
