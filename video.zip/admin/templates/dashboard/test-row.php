<div class="test">
	<span class="text-small"><?php echo $name ?></span>
	<span class="fa fa-close fore-color-2"></span>
</div>
